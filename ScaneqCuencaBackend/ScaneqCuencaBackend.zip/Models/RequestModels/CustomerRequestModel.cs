﻿namespace ScaneqCuencaBackend.Models.RequestModels
{
    public class CustomerRequestModel
    {
        public string Name { get; set; }
    }
}
