﻿namespace ScaneqCuencaBackend.Models.RequestModels
{
    public class VehicleTypeRequest
    {
        public string type { get; set; }
    }
}
