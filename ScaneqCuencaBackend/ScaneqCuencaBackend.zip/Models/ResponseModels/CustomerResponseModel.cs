﻿namespace ScaneqCuencaBackend.Models.ResponseModels
{
    public class CustomerResponseModel
    {
        public int Id { get; set; }
        public string Name { get; set; }
    }
}
